/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/** @author Nícolas Ferri
 * Data: 25/11/2025
 */
public class Vacinas {
    //Atributos
    private int id;
    private String nome;
    private float custo;
    private int  qtd;
    
    //Métodos
    public void setId(int v_id) {
        this.id = v_id;
    }
    public void setNome(String v_nome) {
        this.nome = v_nome;
    }
    public void setCusto(float v_custo) {
        this.custo = v_custo;
    }
    public void setQtd(int v_qtd) {
        this.qtd = v_qtd;
    }
    public int getId() {
        return this.id;
    }
    public String getNome() {
        return this.nome;
    }
    public float getCusto() {
        return this.custo;
    }
    public int getQtd() {
        return this.qtd;
    }          
}
