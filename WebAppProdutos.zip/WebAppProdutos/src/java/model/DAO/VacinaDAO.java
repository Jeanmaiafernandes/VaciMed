/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.DAO;
import model.Vacinas;
import Config.ConectaBanco;

import java.sql.*;
import java.util.*;

/**
 *
 * @author Nícolas Ferri
 */
public class VacinaDAO {
    // + cadastrar( Vacina ): boolean
    public boolean cadastrar( Vacinas vac ) throws ClassNotFoundException{    
        Connection conn;
        conn = null;
        try{
            conn = ConectaBanco.conectar();
            Statement stmt = conn.createStatement();
            //            INSERT INTO vacinas(nome, custo, qtd) VALUES('Anti-Tetânica', 150.75, 20)
            String sql = "INSERT INTO vacinas(nome, custo, qtd) VALUES('" + vac.getNome() + "', " + vac.getCusto()+ ", " + vac.getQtd() + ")";
            stmt.executeUpdate(sql); // GO - RUN -> INSERT, UPDATE, DELETE
            conn.close();
        }catch(SQLException ex){
            System.out.println("Erro SQL: " + ex);
            return false;
        }
        return true;
    }
    
    public List consultar_geral( ) throws ClassNotFoundException{
        List lista = new ArrayList();
        
        Connection conn = null;
        try{
            conn = ConectaBanco.conectar();
            Statement stmt = conn.createStatement();
            //            SELECT * from vacinas
            String sql = "SELECT * from vacinas";
            ResultSet rs = stmt.executeQuery(sql); // SELECT
            
            int n_reg = 0;
            while (rs.next()){
                Vacinas vac = new Vacinas();
                vac.setId(Integer.parseInt(rs.getString("pk_id")));
                vac.setNome(rs.getString("nome"));
                vac.setCusto(Float.parseFloat(rs.getString("custo")));
                vac.setQtd(Integer.parseInt(rs.getString("qtd")));
                lista.add(vac);
                n_reg++;
            }
            conn.close();
            
            if (n_reg == 0){
                return null;
            }else{
                return lista;
            }                                   
        }catch(SQLException ex){
            System.out.println("Erro SQL: " + ex);
            return null;
        }        
    }
    
    public Vacinas consultar_id( Vacinas v_vac ) throws ClassNotFoundException{
        Connection conn = null;
        try{
            conn = ConectaBanco.conectar();
            Statement stmt = conn.createStatement();
            //            SELECT * FROM vacinas WHERE pk_id = 3
            String sql = "SELECT * FROM vacinas WHERE pk_id = " + v_vac.getId();
            ResultSet rs = stmt.executeQuery(sql); // SELECT
            
            if(rs.next()){ 
                Vacinas vac = new Vacinas(); // Instância
                vac.setId(Integer.parseInt(rs.getString("pk_id")));
                vac.setNome(rs.getString("nome"));
                vac.setCusto(Float.parseFloat(rs.getString("custo")));
                vac.setQtd(Integer.parseInt(rs.getString("qtd")));
                conn.close();
                return vac;
            } else {
                conn.close();
                return null;                               
            }
        }catch(SQLException ex){
            System.out.println("Erro SQL: " + ex);
            return null;
        }        
    }    
    
    public Vacinas consultar_nome( Vacinas v_vac ) throws ClassNotFoundException{
        Connection conn = null;
        try{
            conn = ConectaBanco.conectar();
            Statement stmt = conn.createStatement();        
             //           SELECT * FROM vacinas WHERE nome like 'Ant%'
            String sql = "SELECT * FROM vacinas WHERE nome = '" + v_vac.getNome() + "'";
            ResultSet rs = stmt.executeQuery(sql); // SELECT
            
            if(rs.next()){ 
                Vacinas vac = new Vacinas(); // Instância
                vac.setId(Integer.parseInt(rs.getString("pk_id")));
                vac.setNome(rs.getString("nome"));
                vac.setCusto(Float.parseFloat(rs.getString("custo")));
                vac.setQtd(Integer.parseInt(rs.getString("qtd")));
                conn.close();
                return vac;
            } else {
                conn.close();
                return null;                               
            }
        }catch(SQLException ex){
            System.out.println("Erro SQL: " + ex);
            return null;
        }        
    }  
    
    public List consultar_nome( String v_nome ) throws ClassNotFoundException{
        List lista = new ArrayList();
        
        Connection conn = null;
        try{
            conn = ConectaBanco.conectar();
            Statement stmt = conn.createStatement();
            //            SELECT * from vacinas
            String sql = "SELECT * from vacinas WHERE nome like '%" + v_nome + "%'";
            ResultSet rs = stmt.executeQuery(sql); // SELECT
            
            int n_reg = 0;
            while (rs.next()){
                Vacinas vac = new Vacinas();
                vac.setId(Integer.parseInt(rs.getString("pk_id")));
                vac.setNome(rs.getString("nome"));
                vac.setCusto(Float.parseFloat(rs.getString("custo")));
                vac.setQtd(Integer.parseInt(rs.getString("qtd")));
                lista.add(vac);
                n_reg++;
            }
            conn.close();
            
            if (n_reg == 0){
                return null;
            }else{
                return lista;
            }                                   
        }catch(SQLException ex){
            System.out.println("Erro SQL: " + ex);
            return null;
        }        
    }
    
    public boolean excluir( Vacinas vac ) throws ClassNotFoundException{    
        Connection conn = null;
        try{
            conn = ConectaBanco.conectar();
            Statement stmt = conn.createStatement();
            //            DELETE FROM produtos WHERE pk_id = 4;
            String sql = "DELETE FROM produtos WHERE pk_id = " + vac.getId();
            int result = stmt.executeUpdate(sql); // GO - RUN -> INSERT, UPDATE, DELETE
            if (result==0){
                return false;                 
            }else{
                return true;                 
            }              
        }catch(SQLException ex){
            System.out.println("Erro SQL: " + ex);
            return false;
        } 
        
    }

    public boolean alterar( Vacinas vac ) throws ClassNotFoundException{    
        Connection conn = null;
        try{
            conn = ConectaBanco.conectar();
            Statement stmt = conn.createStatement();
            //          //UPDATE vacinas set nome='Mouse Microsoft', valor=250.75, qtd=50 WHERE pk_id = 2;   
            String sql = "UPDATE vacinas set nome='" + vac.getNome() + "', valor=" + vac.getCusto()+ ", qtd=" + vac.getQtd() + " WHERE pk_id = " + vac.getId();
            stmt.executeUpdate(sql); // GO - RUN -> INSERT, UPDATE, DELETE
            conn.close();
        }catch(SQLException ex){
            System.out.println("Erro SQL: " + ex);
            return false;
        }
        return true;
    }
    
    
}
